/**
 * Página inicial do site do Laboratório de Melhoramento de Plantas do INPA
 * Apresenta informações institucionais, pesquisas, equipe e contato
 */

import { useState } from 'react'
import { Leaf, Microscope, Users, BookOpen, Mail, Phone, MapPin, Award, Target, Lightbulb } from 'lucide-react'
import { Button } from '../components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card'
import { Badge } from '../components/ui/badge'

export default function Home() {
  const [activeTab, setActiveTab] = useState('sobre')

  /**
   * Dados das pesquisas em andamento
   */
  const pesquisas = [
    {
      titulo: "Melhoramento Genético de Açaí",
      descricao: "Desenvolvimento de variedades de açaí com maior produtividade e resistência a doenças",
      area: "Fruticultura",
      status: "Em andamento"
    },
    {
      titulo: "Conservação de Germoplasma Amazônico",
      descricao: "Preservação e caracterização de espécies nativas com potencial econômico",
      area: "Conservação",
      status: "Contínuo"
    },
    {
      titulo: "Plantas Medicinais da Amazônia",
      descricao: "Estudo fitoquímico e melhoramento de plantas com propriedades medicinais",
      area: "Farmacologia",
      status: "Em andamento"
    }
  ]

  /**
   * Dados da equipe científica
   */
  const equipe = [
    {
      nome: "Dr. Maria Silva Santos",
      cargo: "Coordenadora do Laboratório",
      especialidade: "Melhoramento Genético Vegetal",
      foto: "https://pub-cdn.sider.ai/u/U0W8H74R2R4/web-coder/685c7f6b9ac9f965237c5c3e/resource/b72c718c-991b-4ab7-a274-18ebf1a902c7.jpg"
    },
    {
      nome: "Dr. João Carlos Oliveira",
      cargo: "Pesquisador Sênior",
      especialidade: "Biotecnologia Vegetal",
      foto: "https://pub-cdn.sider.ai/u/U0W8H74R2R4/web-coder/685c7f6b9ac9f965237c5c3e/resource/a0f8a05b-533c-4b93-88de-e9e20248cd67.jpg"
    },
    {
      nome: "Dra. Ana Paula Costa",
      cargo: "Pesquisadora",
      especialidade: "Conservação de Germoplasma",
      foto: "https://pub-cdn.sider.ai/u/U0W8H74R2R4/web-coder/685c7f6b9ac9f965237c5c3e/resource/fbc0a7f0-19ac-45aa-b336-9672dbf5599b.jpg"
    }
  ]

  /**
   * Dados das publicações recentes
   */
  const publicacoes = [
    {
      titulo: "Caracterização Genética de Variedades de Açaí da Amazônia",
      revista: "Brazilian Journal of Botany",
      ano: "2024",
      autores: "Santos, M.S. et al."
    },
    {
      titulo: "Potencial Biotecnológico de Plantas Medicinais Amazônicas",
      revista: "Plant Science International",
      ano: "2024",
      autores: "Oliveira, J.C. et al."
    },
    {
      titulo: "Conservação ex-situ de Espécies Nativas da Amazônia",
      revista: "Conservation Biology",
      ano: "2023",
      autores: "Costa, A.P. et al."
    }
  ]

  return (
    <div className="min-h-screen bg-gradient-to-b from-green-50 to-white">
      {/* Header/Hero Section */}
      <header className="relative bg-gradient-to-r from-green-700 to-green-600 text-white">
        <div className="absolute inset-0 bg-black/20"></div>
        <div className="relative max-w-7xl mx-auto px-4 py-16 sm:py-24">
          <div className="text-center">
            <div className="flex justify-center mb-6">
              <div className="bg-white/10 p-4 rounded-full">
                <Leaf className="h-16 w-16 text-green-200" />
              </div>
            </div>
            <h1 className="text-4xl sm:text-6xl font-bold mb-6">
              Laboratório de Melhoramento
              <br />
              <span className="text-green-200">de Plantas</span>
            </h1>
            <p className="text-xl sm:text-2xl mb-8 text-green-100">
              Instituto Nacional de Pesquisas da Amazônia - INPA
            </p>
            <p className="text-lg mb-8 max-w-3xl mx-auto text-green-50">
              Desenvolvendo soluções científicas para o aproveitamento sustentável da biodiversidade amazônica
              através do melhoramento genético e conservação de plantas nativas.
            </p>
            <Button size="lg" className="bg-white text-green-700 hover:bg-green-50">
              Conheça Nossas Pesquisas
            </Button>
          </div>
        </div>
      </header>

      {/* Navigation Tabs */}
      <nav className="bg-white shadow-sm sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex space-x-8 overflow-x-auto py-4">
            {[
              { id: 'sobre', label: 'Sobre o Lab', icon: Target },
              { id: 'pesquisas', label: 'Pesquisas', icon: Microscope },
              { id: 'equipe', label: 'Equipe', icon: Users },
              { id: 'publicacoes', label: 'Publicações', icon: BookOpen },
              { id: 'contato', label: 'Contato', icon: Mail }
            ].map(({ id, label, icon: Icon }) => (
              <button
                key={id}
                onClick={() => setActiveTab(id)}
                className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-colors whitespace-nowrap ${
                  activeTab === id
                    ? 'bg-green-100 text-green-700 border-b-2 border-green-600'
                    : 'text-gray-600 hover:text-green-600 hover:bg-green-50'
                }`}
              >
                <Icon className="h-4 w-4" />
                <span>{label}</span>
              </button>
            ))}
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-12">
        {/* Sobre o Laboratório */}
        {activeTab === 'sobre' && (
          <div className="space-y-12">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">Sobre o Laboratório</h2>
              <p className="text-lg text-gray-600 max-w-3xl mx-auto">
                Referência nacional em pesquisa e desenvolvimento de hortaliças amazônicas
              </p>
            </div>

            <div className="grid md:grid-cols-2 gap-12 items-center">
              <div>
                <h3 className="text-2xl font-semibold text-gray-900 mb-6">Nossa Missão</h3>
                <p className="text-gray-600 mb-6 leading-relaxed">
                  O Laboratório de Melhoramento de Plantas do INPA dedica-se à pesquisa científica voltada 
                  para o desenvolvimento sustentável da Amazônia. Nosso trabalho contribui para a conservação 
                  da biodiversidade e o aproveitamento econômico responsável das espécies vegetais da região.
                </p>
                <div className="grid grid-cols-2 gap-4">
                  <div className="flex items-center space-x-3">
                    <Award className="h-6 w-6 text-green-600" />
                    <span className="text-sm font-medium">40+ Anos de Pesquisa</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <Lightbulb className="h-6 w-6 text-green-600" />
                    <span className="text-sm font-medium">50+ Projetos Concluídos</span>
                  </div>
                </div>
              </div>
              <div className="relative">
                <img 
                  src="https://pub-cdn.sider.ai/u/U0W8H74R2R4/web-coder/685c7f6b9ac9f965237c5c3e/resource/a7637fec-9339-481d-979f-a12c891c04a8.jpg" 
                  alt="Laboratório de pesquisa" 
                  className="w-full h-80 object-cover rounded-lg shadow-lg"
                />
              </div>
            </div>

            {/* Áreas de Atuação */}
            <div className="grid md:grid-cols-3 gap-8">
              <Card className="hover:shadow-lg transition-shadow">
                <CardHeader className="text-center">
                  <div className="mx-auto bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mb-4">
                    <Leaf className="h-8 w-8 text-green-600" />
                  </div>
                  <CardTitle>Melhoramento Genético</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 text-center">
                    Desenvolvimento de variedades melhoradas com características desejáveis 
                    para produtividade e resistência.
                  </p>
                </CardContent>
              </Card>

              <Card className="hover:shadow-lg transition-shadow">
                <CardHeader className="text-center">
                  <div className="mx-auto bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mb-4">
                    <Microscope className="h-8 w-8 text-blue-600" />
                  </div>
                  <CardTitle>Biotecnologia</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 text-center">
                    Aplicação de técnicas biotecnológicas avançadas para caracterização 
                    e manipulação genética de plantas.
                  </p>
                </CardContent>
              </Card>

              <Card className="hover:shadow-lg transition-shadow">
                <CardHeader className="text-center">
                  <div className="mx-auto bg-orange-100 w-16 h-16 rounded-full flex items-center justify-center mb-4">
                    <Target className="h-8 w-8 text-orange-600" />
                  </div>
                  <CardTitle>Conservação</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 text-center">
                    Preservação e manutenção de bancos de germoplasma de espécies 
                    nativas da Amazônia.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        )}

        {/* Pesquisas */}
        {activeTab === 'pesquisas' && (
          <div className="space-y-8">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">Pesquisas em Andamento</h2>
              <p className="text-lg text-gray-600">
                Projetos que estão transformando o conhecimento sobre plantas amazônicas
              </p>
            </div>

            <div className="grid gap-6">
              {pesquisas.map((pesquisa, index) => (
                <Card key={index} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <CardTitle className="text-xl mb-2">{pesquisa.titulo}</CardTitle>
                        <CardDescription className="text-base">
                          {pesquisa.descricao}
                        </CardDescription>
                      </div>
                      <div className="ml-4 space-y-2">
                        <Badge variant="secondary">{pesquisa.area}</Badge>
                        <Badge 
                          variant={pesquisa.status === 'Em andamento' ? 'default' : 'outline'}
                          className="block text-center"
                        >
                          {pesquisa.status}
                        </Badge>
                      </div>
                    </div>
                  </CardHeader>
                </Card>
              ))}
            </div>

            <div className="bg-green-50 rounded-lg p-8 text-center">
              <Microscope className="h-12 w-12 text-green-600 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-2">
                Interessado em Colaborar?
              </h3>
              <p className="text-gray-600 mb-4">
                Estamos sempre abertos a parcerias e colaborações científicas
              </p>
              <Button className="bg-green-600 hover:bg-green-700">
                Entre em Contato
              </Button>
            </div>
          </div>
        )}

        {/* Equipe */}
        {activeTab === 'equipe' && (
          <div className="space-y-8">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">Nossa Equipe</h2>
              <p className="text-lg text-gray-600">
                Pesquisadores dedicados ao avanço da ciência vegetal amazônica
              </p>
            </div>

            <div className="grid md:grid-cols-3 gap-8">
              {equipe.map((membro, index) => (
                <Card key={index} className="text-center hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <img 
                      src={membro.foto} 
                      alt={membro.nome}
                      className="w-32 h-32 rounded-full mx-auto mb-4 object-cover"
                    />
                    <CardTitle className="text-xl">{membro.nome}</CardTitle>
                    <CardDescription className="text-green-600 font-medium">
                      {membro.cargo}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Badge variant="outline" className="text-sm">
                      {membro.especialidade}
                    </Badge>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* Publicações */}
        {activeTab === 'publicacoes' && (
          <div className="space-y-8">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">Publicações Científicas</h2>
              <p className="text-lg text-gray-600">
                Compartilhando conhecimento com a comunidade científica mundial
              </p>
            </div>

            <div className="grid gap-6">
              {publicacoes.map((pub, index) => (
                <Card key={index} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <CardTitle className="text-lg text-green-700">{pub.titulo}</CardTitle>
                    <CardDescription>
                      <div className="flex flex-wrap gap-4 text-sm">
                        <span><strong>Revista:</strong> {pub.revista}</span>
                        <span><strong>Ano:</strong> {pub.ano}</span>
                        <span><strong>Autores:</strong> {pub.autores}</span>
                      </div>
                    </CardDescription>
                  </CardHeader>
                </Card>
              ))}
            </div>

            <div className="bg-blue-50 rounded-lg p-8 text-center">
              <BookOpen className="h-12 w-12 text-blue-600 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-2">
                Acesso Completo às Publicações
              </h3>
              <p className="text-gray-600 mb-4">
                Consulte nossa biblioteca digital para acesso a todas as publicações
              </p>
              <Button variant="outline" className="border-blue-600 text-blue-600 hover:bg-blue-50">
                Ver Biblioteca Digital
              </Button>
            </div>
          </div>
        )}

        {/* Contato */}
        {activeTab === 'contato' && (
          <div className="space-y-8">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">Entre em Contato</h2>
              <p className="text-lg text-gray-600">
                Estamos prontos para colaborar em pesquisas e projetos
              </p>
            </div>

            <div className="grid md:grid-cols-2 gap-12">
              <div className="space-y-8">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <MapPin className="h-5 w-5 text-green-600" />
                      <span>Localização</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-600">
                      Instituto Nacional de Pesquisas da Amazônia - INPA<br />
                      Av. André Araújo, 2936<br />
                      Petrópolis, Manaus - AM<br />
                      CEP: 69067-375
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <Phone className="h-5 w-5 text-green-600" />
                      <span>Telefone</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-600">
                      +55 (92) 3643-3000<br />
                      Ramal: 3456
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <Mail className="h-5 w-5 text-green-600" />
                      <span>E-mail</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-600">
                      labplantas@inpa.gov.br<br />
                      coordenacao.labplantas@inpa.gov.br
                    </p>
                  </CardContent>
                </Card>
              </div>

              <div>
                <img 
                  src="https://pub-cdn.sider.ai/u/U0W8H74R2R4/web-coder/685c7f6b9ac9f965237c5c3e/resource/1d6642bf-da67-4669-b630-c23ebf7fd752.jpg" 
                  alt="Plantas da Amazônia"
                  className="w-full h-96 object-cover rounded-lg shadow-lg mb-6"
                />
                <div className="bg-green-50 p-6 rounded-lg">
                  <h3 className="font-semibold text-gray-900 mb-2">Horário de Funcionamento</h3>
                  <div className="space-y-1 text-gray-600">
                    <p>Segunda a Sexta: 8:00 - 17:00</p>
                    <p>Sábado: 8:00 - 12:00</p>
                    <p>Domingo: Fechado</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid md:grid-cols-3 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <Leaf className="h-8 w-8 text-green-400" />
                <span className="text-xl font-bold">Lab Plantas INPA</span>
              </div>
              <p className="text-gray-400">
                Desenvolvendo soluções científicas para o aproveitamento sustentável 
                da biodiversidade amazônica.
              </p>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Links Úteis</h3>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-green-400 transition-colors">INPA</a></li>
                <li><a href="#" className="hover:text-green-400 transition-colors">Portal da Transparência</a></li>
                <li><a href="#" className="hover:text-green-400 transition-colors">Biblioteca Digital</a></li>
                <li><a href="#" className="hover:text-green-400 transition-colors">Parceiros</a></li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Contato Rápido</h3>
              <div className="space-y-2 text-gray-400">
                <p className="flex items-center space-x-2">
                  <Mail className="h-4 w-4" />
                  <span>labplantas@inpa.gov.br</span>
                </p>
                <p className="flex items-center space-x-2">
                  <Phone className="h-4 w-4" />
                  <span>+55 (92) 3643-3000</span>
                </p>
              </div>
            </div>
          </div>
          <div className="border-t border-gray-800 pt-8 mt-8 text-center text-gray-400">
            <p>&copy; 2024 Laboratório de Melhoramento de Plantas - INPA. Todos os direitos reservados.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}